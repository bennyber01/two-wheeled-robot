#include "HardwareMediator.h"
#include "Cerebrum.h"
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

#include <boost/date_time/posix_time/posix_time.hpp>

HardwareMediator::HardwareMediator(Cerebrum * cerebrum)
{
	this -> cerebrum = cerebrum;
	srand (time(NULL));
}

HardwareMediator::~HardwareMediator(void)
{
	// Ask thread to stop
	communicationThread.interrupt();

	// Join - wait when thread actually exits
	communicationThread.join();
	cerebrum -> GetGraphics().println("HardwareMediator::~HardwareMediator : communication thread ended");
}

bool HardwareMediator::InitHardwareModule()
{
	cerebrum -> GetGraphics().println("START : HardwareMediator::InitHardwareModule");

	// Start thread
	communicationThread = boost::thread(&UpdateRobotLocationThreadMethod, this);

	cerebrum -> GetGraphics().println("FINISHED : HardwareMediator::InitHardwareModule");
	
	return true;
}

void HardwareMediator::UpdateRobotLocationThreadMethod(void * lparam)
{
	HardwareMediator * hardwareMediator = (HardwareMediator*) lparam;

	MotorsTicks motorsTicks;

	while (1)
	{
		motorsTicks.leftMotorTicks  = 5;//rand() % 100;
		motorsTicks.rightMotorTicks = 5;//rand() % 100;
		hardwareMediator -> cerebrum -> UpdateRobotLocation(motorsTicks);
		boost::this_thread::sleep_for(boost::chrono::milliseconds(600));
	}
}
