#include "graphics.h"
#include <stdio.h>
#include <stdarg.h>

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>

#include "bitmap_image.hpp"

Graphics::Graphics()
{
	bitmap_image image(1024,1024);
	image.clear(0);

	image_drawer draw(image);

	draw.pen_width(3);
	draw.pen_color(255,0,0);
	draw.circle(image.width() / 2 + 100, image.height() / 2, 100);

	draw.pen_width(2);
	draw.pen_color(0,255,255);
	draw.ellipse(image.width() / 2, image.height() / 2, 200,350);

	draw.pen_width(1);
	draw.pen_color(255,255,0);
	draw.rectangle(50,50,250,400);

	draw.pen_color(0,255,0);
	draw.rectangle(450,250,850,880);

	image.save_image("test17_image_drawer.bmp");
}

Graphics::~Graphics()
{
}

void Graphics::Draw(const MotorsTicks & motorsTicks)
{
}

void Graphics::print(const char * format, ...)
{
    va_list args;
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
}

void Graphics::println(const char * format, ...)
{
	va_list args;
	va_start(args, format);
	vprintf(format, args);
	va_end(args);
	printf("\r\n");
}

bool Graphics::SaveAsBMP(const WheelsLocationsHolder & wheelsLocationsHolder, char * fileName)
{
	double minX = 0;
	double maxX = 0;
	double minY = 0;
	double maxY = 0;
	for (int i = 0; i < wheelsLocationsHolder.size(); ++i)
	{
		if (i == 0 || minX > wheelsLocationsHolder[i].leftWheelLoc.x) minX = wheelsLocationsHolder[i].leftWheelLoc.x;
		if (i == 0 || maxX < wheelsLocationsHolder[i].leftWheelLoc.x) maxX = wheelsLocationsHolder[i].leftWheelLoc.x;
		if (i == 0 || minY > wheelsLocationsHolder[i].leftWheelLoc.y) minY = wheelsLocationsHolder[i].leftWheelLoc.y;
		if (i == 0 || maxY < wheelsLocationsHolder[i].leftWheelLoc.y) maxY = wheelsLocationsHolder[i].leftWheelLoc.y;

		if (minX > wheelsLocationsHolder[i].rightWheelLoc.x) minX = wheelsLocationsHolder[i].rightWheelLoc.x;
		if (maxX < wheelsLocationsHolder[i].rightWheelLoc.x) maxX = wheelsLocationsHolder[i].rightWheelLoc.x;
		if (minY > wheelsLocationsHolder[i].rightWheelLoc.y) minY = wheelsLocationsHolder[i].rightWheelLoc.y;
		if (maxY < wheelsLocationsHolder[i].rightWheelLoc.y) maxY = wheelsLocationsHolder[i].rightWheelLoc.y;
	}

	minX -= 20;
	minY -= 20;
	maxX += 20;
	maxY += 20;

	bitmap_image image(maxX - minX, maxY - minY);
	image.clear(0);

	image_drawer draw(image);

	for (int i = 0; i < wheelsLocationsHolder.size(); ++i)
	{
		const WheelsLocation & currLoc = wheelsLocationsHolder[i];

		draw.pen_width(1);
		draw.pen_color(255,0,0);
		int x = currLoc.leftWheelLoc.x - minX;
		int y = currLoc.leftWheelLoc.y - minY;
		draw.circle(x, y, 3);

		draw.pen_width(1);
		draw.pen_color(0,255,0);
		x = currLoc.rightWheelLoc.x - minX;
		y = currLoc.rightWheelLoc.y - minY;
		draw.circle(x, y, 3);
	}

	image.save_image(fileName);

	return true;
}
