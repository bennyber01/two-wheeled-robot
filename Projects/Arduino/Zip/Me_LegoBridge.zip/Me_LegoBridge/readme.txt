Copy this lib into arduino libraries directory:
'arduino-1.0.5-r2\libraries\Me_LegoBridge'