//           Ascended International
//
//             Copyright (c) 2010
//
//            All Rights Reserved
// ------------------------------------------------------------------------------
//    * DO NOT REMOVE THIS HEADER. DO NOT MODIFY THIS HEADER *
/**********************************************************************************
 * You may use this class for non-commerical purposes. If you wish to use this    *
 * software for a commercial pupose please contact Ascended International at:     *
 * mark@ascended.com.au                                                           *
 *                                                                                *
 * When using this free class, no warranty express or implied is offered.         *
 * In no event shall Ascended International, any of it's employees or shareholds  *
 * be held liable for any direct, indirect, special, exemplary, incidental or     *
 * consequential damages however caused.                                          *
 *                                                                                *
 * If you modify this class, please add your name and the date below as a         *
 * contributor, without removing this notice or modifying it in any way, shape    *
 * or form.                                                                       *
 **********************************************************************************/
/*
 Contributors:
 * 16 Sep 2010, Mark Harris - Initial code, maths and development [ markh@rris.com.au ]
 * 17 Sep 2010, Mark Harris - increased accuracy of 4th order poly by 6 decimal places
 * 26 Sep 2010, Mark Harris - Rewrote poly functions to get accuracty within 1mm
 */

    
using System;
using Microsoft.SPOT;
using GHIElectronics.NETMF.Hardware;
using GHIElectronics.NETMF.System;
using Microsoft.SPOT.Hardware;

namespace Ascended.SPOT.Sensors.Distance
{
    /// <summary>
    /// Settings for running the sensor
    /// </summary>
    public enum SensorMode
    {
        /// <summary>
        /// Define your own settings using the properties on the class
        /// </summary>
        Custom,
        /// <summary>
        /// Read the sensor value out as fast as possible. No filtering or averaging will be done.
        /// </summary>
        FastestRead,
        /// <summary>
        /// Read the sensor as accurately as possible. All filtering and averaging will be done - if required.
        /// </summary>
        MostAccurate,
        /// <summary>
        /// The the accurately, but also try to do it quickly. This is best for most uses.
        /// </summary>
        BestTradeoff
    }
    
    
    
    /// <summary>
    /// Driver for Sharp Sharp2Y0A21 (Infrared Proximity Sensor Short Range - Sharp GP2Y0A21).
    
    /// 
    /// Class written by Mark Harris, mark@ascended.com.au/markh@rris.com.au
    /// </summary>
    public class Sharp2Y0A21
    {
        protected AnalogIn sensor;

        protected double[] movingValues;
        int movingPos;

        double[] data;
        double[] values;

        /// <summary>
        /// Create a new instance of Sharp2Y0A21. You should sleep for *at least* 50ms after instantiating this class.
        /// The sensor does not produce accurate results for at least this time.
        /// </summary>
        /// <param name="pin">Pin the sensor's vout is connected to.</param>
        public Sharp2Y0A21(Cpu.Pin pin)
        {
            Initialise(pin);

            SetDefaults();
            
            MinimumDistanceCapability = 20;
            MaximumDistanceCapability = 65;
        }

        /// <summary>
        /// Create a new instance of Sharp2D120X. You should sleep for *at least* 50ms after instantiating this class.
        /// The sensor does not produce accurate results for at least this time.
        /// </summary>
        /// <param name="pin">Pin the sensor's vout is connected to.</param>
        /// <param name="mode">Set the sensor read mode defaults</param>
        public Sharp2Y0A21(Cpu.Pin pin, SensorMode mode)
        {
            Initialise(pin);

            SensorReadMode = mode;
            if (mode == SensorMode.Custom)
            {
                SetDefaults();
            }
    
            MinimumDistanceCapability = 20;
            MaximumDistanceCapability = 65;
        }

        internal void SetDefaults()
        {
            UseMovingAverage = false;
            MovingAverageSize = 5;

            UseAveraging = true;
            AverageSampleCount = 10;

            movingValues = new double[MovingAverageSize];
            FillMovingAverageValues();
        }

        internal void Initialise(Cpu.Pin pin)
        {
            sensor = new AnalogIn((AnalogIn.Pin)pin);
            sensor.SetLinearScale(0, 3300);
        }

        /// <summary>
        /// Returns the distance in centimetres and will apply any filtering or averaging before returning the value.
        /// </summary>
        /// <returns>The distance the sensor is reading in CM.</returns>
        public double GetDistanceInCM()
        {
            double distance = 0;

            if (UseAveraging)
            {
                data = new double[AverageSampleCount];

                double min = Double.MaxValue;
                double max = Double.MinValue;

                for (int i = 0; i < AverageSampleCount; i++)
                {
                    double val = ReadSensorValue();
                    data[i] = val;
                    distance += val;

                    if (UseFiltering)
                    {
                        if (min > val)
                            min = val;

                        if (max < val)
                            max = val;
                    }
                }

                distance = distance / AverageSampleCount; // faster than /=

                if (UseFiltering)
                {
                    // do we need to do cleanup through deviation?
                    if (!(max == min || max - min < 1))
                    {
                        // trim down the data
                        double stdDev = StandardDeviation(data, distance);

                        // Standard Dev is too high for our liking!
                        if (stdDev > 0.5)
                        {
                            int candidates = 0;

                            values = new double[AverageSampleCount];

                            for (int i = 0; i < AverageSampleCount; i++)
                            {
                                double dat = data[i];
                                if (dat < distance + stdDev && dat > distance - stdDev)
                                    values[candidates++] = dat;
                            }

                            distance = Average(values, candidates - 1);
                        }
                    }
                }
            }
            else
            {
                distance = ReadSensorValue();
            }

            if (UseMovingAverage)
            {
                AddMovingAverage(distance);
                return Average(movingValues);
            }

            return distance;
        }

        protected double ReadSensorValue()
        {
            int x = sensor.Read();

            if (x > 970) // less than 28cm
            {
                return 0.00000000131735227029556 * MathEx.Pow(x, 4) -
                    0.00000588207740775979 * MathEx.Pow(x, 3) +
                    0.00984274026340972 * MathEx.Pow(x, 2) -
                    7.34230389208274 * x +
                    2091.1617416433;

            }
            else if (x > 680) // less than ~44cm
            {
                return -0.00000000000000850459495296198 * MathEx.Pow(x, 6) +
                    0.0000000000404907863601567 * MathEx.Pow(x, 5) -
                    0.0000000786246323722896 * MathEx.Pow(x, 4) +
                    0.00007932114058495 * MathEx.Pow(x, 3) -
                    0.0434598791721258 * MathEx.Pow(x, 2) +
                    12.0026030117761 * x -
                    1199.16124650975;
            }
            else // not so accurate, sensor absolute max limit 60cm.
            {
                return -0.00000740565636533214 * MathEx.Pow(x, 3) +
                    0.0166287013999877 * MathEx.Pow(x, 2) -
                    12.5032985098457 * x +
                    3186.33733622086;

            }
        }
    }
}
