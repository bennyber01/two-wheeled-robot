var searchData=
[
  ['begin',['begin',['../class_analog_distance_sensor.html#aab16a8975b46d82ac9fd7077e839f35c',1,'AnalogDistanceSensor::begin()'],['../class_analog_distance_sensor.html#a57a38f5fd395392d6a68e57bf2e86d4b',1,'AnalogDistanceSensor::begin(int distancePin)'],['../class_ultrasonic_distance_sensor.html#a936da791e81d90e386850913cbcbab29',1,'UltrasonicDistanceSensor::begin()'],['../class_ultrasonic_distance_sensor.html#a771d720e7d6b20e0e303e4a1fd411095',1,'UltrasonicDistanceSensor::begin(int echoPin, int trigPin)']]]
];
