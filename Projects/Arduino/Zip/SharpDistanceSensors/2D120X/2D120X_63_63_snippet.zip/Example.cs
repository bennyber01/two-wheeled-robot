using System;
using Microsoft.SPOT;
using GHIElectronics.NETMF.Hardware;
using Microsoft.SPOT.Hardware;
using System.Threading;
using Ascended.SPOT.Sensors.Distance;

namespace Ascended.SPOT.Tests
{
    public class Program
    {
        public static void Main()
        {
            using (Sharp2D120X sensor = new Sharp2D120X((Cpu.Pin)AnalogIn.Pin.Ain0))
            {
                while (true)
                {
                    Debug.Print("Distance: " + sensor.GetDistanceInCM() + "cm");

                    Thread.Sleep(1000);
                }
            }

        }

    }
}


