//           Ascended International
//
//             Copyright (c) 2010
//
//            All Rights Reserved
// ------------------------------------------------------------------------------
//    * DO NOT REMOVE THIS HEADER. DO NOT MODIFY THIS HEADER *
/**********************************************************************************
 * You may use this class for non-commerical purposes. If you wish to use this    *
 * software for a commercial pupose please contact Ascended International at:     *
 * mark@ascended.com.au                                                           *
 *                                                                                *
 * When using this free class, no warranty express or implied is offered.         *
 * In no event shall Ascended International, any of it's employees or shareholds  *
 * be held liable for any direct, indirect, special, exemplary, incidental or     *
 * consequential damages however caused.                                          *
 *                                                                                *
 * If you modify this class, please add your name and the date below as a         *
 * contributor, without removing this notice or modifying it in any way, shape    *
 * or form.                                                                       *
 **********************************************************************************/
/*
 Contributors:
 * 16 Sep 2010, Mark Harris - Initial code, maths and development [ markh@rris.com.au ]
 * 17 Sep 2010, Mark Harris - increased accuracy of 4th order poly by 6 decimal places
 * 26 Sep 2010, Mark Harris - Rewrote poly functions to get accuracty within 1mm
 */

using System;
using Microsoft.SPOT;
using GHIElectronics.NETMF.Hardware;
using GHIElectronics.NETMF.System;
using Microsoft.SPOT.Hardware;

namespace Ascended.SPOT.Sensors.Distance
{
    /// <summary>
    /// Settings for running the sensor
    /// </summary>
    public enum SensorMode
    {
        /// <summary>
        /// Define your own settings using the properties on the class
        /// </summary>
        Custom,
        /// <summary>
        /// Read the sensor value out as fast as possible. No filtering or averaging will be done.
        /// </summary>
        FastestRead,
        /// <summary>
        /// Read the sensor as accurately as possible. All filtering and averaging will be done - if required.
        /// </summary>
        MostAccurate,
        /// <summary>
        /// The the accurately, but also try to do it quickly. This is best for most uses.
        /// </summary>
        BestTradeoff
    }
    
    /// <summary>
    /// Driver for Sharp 2D120X (Infrared Proximity Sensor Short Range - Sharp GP2D120XJ00F).
    /// Sparkfun SKU: sku: SEN-08959
    /// TinyCLR SKU: GP2D120
    /// 
    /// Class written by Mark Harris, mark@ascended.com.au/markh@rris.com.au
    /// </summary>
    public class Sharp2D120X
    {
        protected AnalogIn sensor;

        protected double[] movingValues;
        int movingPos;

        double[] data;
        double[] values;

        /// <summary>
        /// Create a new instance of Sharp2D120X. You should sleep for *at least* 50ms after instantiating this class.
        /// The sensor does not produce accurate results for at least this time.
        /// </summary>
        /// <param name="pin">Pin the sensor's vout is connected to.</param>
        public Sharp2D120X(Cpu.Pin pin)
        {
            Initialise(pin);

            SetDefaults();

            MinimumDistanceCapability = 4.75f;
            MaximumDistanceCapability = 26;
        }

        /// <summary>
        /// Create a new instance of Sharp2D120X. You should sleep for *at least* 50ms after instantiating this class.
        /// The sensor does not produce accurate results for at least this time.
        /// </summary>
        /// <param name="pin">Pin the sensor's vout is connected to.</param>
        /// <param name="mode">Set the sensor read mode defaults</param>
        public Sharp2D120X(Cpu.Pin pin, SensorMode mode)
        {
            // initialise the senor
            Initialise(pin);

            SensorReadMode = mode;
            if (mode == SensorMode.Custom)
            {
                SetDefaults();
            }

            MinimumDistanceCapability = 4.75f;
            MaximumDistanceCapability = 26;
        }

        internal void SetDefaults()
        {
            UseMovingAverage = false;
            MovingAverageSize = 5;

            UseAveraging = true;
            AverageSampleCount = 10;

            movingValues = new double[MovingAverageSize];
            FillMovingAverageValues();
        }

        internal void Initialise(Cpu.Pin pin)
        {
            sensor = new AnalogIn((AnalogIn.Pin)pin);
            sensor.SetLinearScale(0, 3300);
        }

        /// <summary>
        /// Returns the distance in centimetres and will apply any filtering or averaging before returning the value.
        /// </summary>
        /// <returns>The distance the sensor is reading in CM.</returns>
        public double GetDistanceInCM()
        {
            double distance = 0;

            if (UseAveraging)
            {
                data = new double[AverageSampleCount];

                double min = Double.MaxValue;
                double max = Double.MinValue;

                for (int i = 0; i < AverageSampleCount; i++)
                {
                    double val = ReadSensorValue();
                    data[i] = val;
                    distance += val;

                    if (UseFiltering)
                    {
                        if (min > val)
                            min = val;

                        if (max < val)
                            max = val;
                    }
                }

                distance = distance / AverageSampleCount; // faster than /=

                if (UseFiltering)
                {
                    // do we need to do cleanup through deviation?
                    if (!(max == min || max - min < 1))
                    {
                        // trim down the data
                        double stdDev = StandardDeviation(data, distance);

                        // Standard Dev is too high for our liking!
                        if (stdDev > 0.5)
                        {
                            int candidates = 0;

                            values = new double[AverageSampleCount];

                            for (int i = 0; i < AverageSampleCount; i++)
                            {
                                double dat = data[i];
                                if (dat < distance + stdDev && dat > distance - stdDev)
                                    values[candidates++] = dat;
                            }

                            distance = Average(values, candidates - 1);
                        }
                    }
                }
            }
            else
            {
                distance = ReadSensorValue();
            }

            if (UseMovingAverage)
            {
                AddMovingAverage(distance);
                return Average(movingValues);
            }

            return distance;
        }

        protected double ReadSensorValue()
        {
            int x = sensor.Read();

            // please do not change this unless you *really* know what you are doing. This took many hours to get right.
            if (x > 670)
            {
                // handles 5cm ~23cm very accurately
                return -0.00000000000000814807570435057 * MathEx.Pow(x, 5) +
                    0.0000000000677479681464555 * MathEx.Pow(x, 4) -
                    0.000000223468684525594 * MathEx.Pow(x, 3) +
                    0.000369147142846821 * MathEx.Pow(x, 2) -
                    0.313961024650693 * x +
                    121.96816964022;
            }
            else
            {
                // actually accurate from 17cm ~ 36cm however the above function is more accurate
                return 0.00000000000000814807570435057 * MathEx.Pow(x, 5) +
                    0.0000000000677479681464555 * MathEx.Pow(x, 4) -
                    0.000000223468684525594 * MathEx.Pow(x, 3) +
                    0.000369147142846821 * MathEx.Pow(x, 2) -
                    0.313961024650693 * x +
                    121.96816964022;
            }

            
        static double StandardDeviation(double[] data, double avg)
        {
            //double avg = 0;
            double totalVariance = 0;
            int max = data.Length;

            if (max == 0)
                return 0;

            // get variance
            for (int i = 0; i < max; i++)
            {
                double variance = data[i] - avg;
                totalVariance = totalVariance + (variance * variance);
            }

            return MathEx.Sqrt(totalVariance / max);
        }

        static double Average(double[] data)
        {
            return Average(data, data.Length);
        }

        static double Average(double[] data, int count)
        {
            double avg = 0;

            for (int i = 0; i < count; i++)
                avg += data[i];

            if (avg == 0 || count == 0)
                return 0;

            return avg / count;
        }

        void AddMovingAverage(double nextValue)
        {
            movingValues[movingPos++] = nextValue;

            if (movingPos >= movingValues.Length)
                movingPos = 0;
        }

        protected void FillMovingAverageValues()
        {
            for (int i = 0; i < movingAverageSize; i++)
            {
                AddMovingAverage(ReadSensorValue());
            }
        }

        private SensorMode sensorReadMode;
        public SensorMode SensorReadMode
        {
            get { return sensorReadMode; }
            set
            {
                if (sensorReadMode == value)
                    return;

                sensorReadMode = value;

                switch (value)
                {
                    case SensorMode.FastestRead:
                        UseAveraging = false;
                        UseFiltering = false;
                        UseMovingAverage = false;
                        break;
                    case SensorMode.MostAccurate:
                        UseAveraging = true;
                        UseFiltering = true;
                        UseMovingAverage = true;
                        AverageSampleCount = 10;
                        MovingAverageSize = 5;
                        break;
                    case SensorMode.BestTradeoff:
                        UseAveraging = true;
                        UseFiltering = false;
                        UseMovingAverage = false;
                        AverageSampleCount = 5;
                        break;
                    case SensorMode.Custom:
                    default:
                        break;
                }
            }
        }

        bool useMovingAverage;
        /// <summary>
        /// Controls whether the system uses moving averages to smooth out values.
        /// This should be True if you have a high speed update, or are movement is slow.
        /// This should be False if you are moving fast or have a slow update rate.
        /// Moving averages introduce some lag into the system, therefore it's only useful with high update speeds or slow movements.
        /// The moving average can take out spikes and other crazy phenomenon efficiently.
        /// </summary>
        public bool UseMovingAverage
        {
            get { return useMovingAverage; }
            set 
            {
                if (useMovingAverage == value)
                    return;

                useMovingAverage = value;

                if (useMovingAverage == true)
                {
                    movingValues = new double[movingAverageSize];
                    movingPos = 0;

                    FillMovingAverageValues();
                }
            }
        }
        
        int movingAverageSize;
        /// <summary>
        /// Gets/Sets the size of the moving average set. If the set is too large, there will be considerable lag. If the set is too small, it will be inefficient.
        /// </summary>
        public int MovingAverageSize
        {
            get { return movingAverageSize; }
            set 
            {
                if (movingAverageSize == value)
                    return;

                movingAverageSize = value;

                movingValues = new double[movingAverageSize];
                movingPos = 0;

                FillMovingAverageValues();
            }
        }

        private bool useFiltering;
        /// <summary>
        /// Gets/Sets whether standard deviation filtering should be used. This only works with UseAveraging turned on. 
        /// If values read have too wide of a range, anything beyond one standard deviation will be culled and ignored.
        /// If you have high speed movement, this will get a good workout and may not be of any benefit.
        /// If you have slow movement with a lot of 'noise' this will clean it up considerably.
        /// </summary>
        public bool UseFiltering
        {
            get { return useFiltering; }
            set
            {
                if (value && !UseAveraging)
                    throw new NotSupportedException("You cannot use filtering without averaging!");

                useFiltering = value;
            }
        }

        /// <summary>
        /// When using averaging, the sensor will take <c>AverageSampleCount</c> samples and then average them to remove some fluctuations.
        /// This works very well at all times and should be left on, vary the sample count based on the speed of code you require, and the speed you move at.
        /// </summary>
        public bool UseAveraging { get; set; }
        /// <summary>
        /// Gets/sets the number of samples to take for averaging.
        /// </summary>
        public int AverageSampleCount { get; set; }

        #region IDisposable Members

        public void Dispose()
        {
            sensor.Dispose();
        }

        #endregion

        /// <summary>
        /// The maximum distance (in centimetres) that the senor can be used.
        /// </summary>
        public float MaximumDistanceCapability { get; protected set; }

        /// <summary>
        /// The minimum distance (in centimetres) that the sensor can be used.
        /// </summary>
        public float MinimumDistanceCapability { get; protected set; }


        public double GetDistanceInInches()
        {
            return GetDistanceInCM() / 2.54;
        }

        public double GetDistanceInMM()
        {
            return GetDistanceInCM() * 10;
        }

        public double GetDistanceInFeet()
        {
            return GetDistanceInCM() * 0.032808399;
        }
        }
    }
}
