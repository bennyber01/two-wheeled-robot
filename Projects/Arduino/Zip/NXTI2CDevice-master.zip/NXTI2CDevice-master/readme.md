# NXT I2C Devices for Arduino

By [Clinton Blackmore](https://launchpad.net/~clinton-blackmore)

The original lib can be found [here](https://launchpad.net/nxti2cdevice)

Licensed GNU LGPL v2.1



# Updates

- Renames Wire.receive => Wire.read
- Renames Wire.send => Wire.write
- Renames "WProgram.h" => "Arduino.h"
